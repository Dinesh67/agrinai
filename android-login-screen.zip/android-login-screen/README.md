#Android UI/UX
#Android Login Screen

<img src="https://cloud.githubusercontent.com/assets/25086018/21963563/dc132d64-db6f-11e6-8e1c-83d0c04a8e9d.png" width="250" height="444">
<img src="https://cloud.githubusercontent.com/assets/25086018/21964046/3551d888-db77-11e6-9a9a-c297e9f235ad.png" width="250" height="444">
